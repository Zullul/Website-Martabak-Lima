-- Database untuk Website Martabak Lima
CREATE DATABASE martabak_lima;
USE martabak_lima;

-- Tabel Admin
CREATE TABLE admin (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert admin default (password: admin123)
INSERT INTO admin (username, password) VALUES 
('admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi');

-- Tabel Menu Packages
CREATE TABLE menu_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Toppings
CREATE TABLE toppings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabel Orders
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(100) NOT NULL,
    customer_phone VARCHAR(20) NOT NULL,
    menu_package_id INT,
    total_price DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (menu_package_id) REFERENCES menu_packages(id)
);

-- Tabel Order Toppings (untuk custom toppings)
CREATE TABLE order_toppings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    topping_id INT,
    quantity INT DEFAULT 1,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (topping_id) REFERENCES toppings(id)
);

-- Sample data untuk menu packages
INSERT INTO menu_packages (name, description, price) VALUES 
('Martabak Manis Original', 'Martabak manis dengan topping dasar', 25000),
('Martabak Telur Special', 'Martabak telur dengan sayuran lengkap', 20000),
('Martabak Mini', 'Ukuran mini untuk cemilan', 15000);

-- Sample data untuk toppings
INSERT INTO toppings (name, price) VALUES 
('Keju', 5000),
('Coklat', 3000),
('Kacang', 2000),
('Susu', 3000),
('Jagung', 2500),
('Sosis', 7000),
('Kornet', 8000);
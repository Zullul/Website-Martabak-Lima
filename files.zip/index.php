<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

$database = new Database();
$db = $database->getConnection();

// Get menu packages
$query = "SELECT * FROM menu_packages WHERE is_active = 1 ORDER BY name";
$stmt = $db->prepare($query);
$stmt->execute();
$menu_packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get toppings
$query = "SELECT * FROM toppings WHERE is_active = 1 ORDER BY name";
$stmt = $db->prepare($query);
$stmt->execute();
$toppings = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Martabak Lima - Martabak Terenak di Kota</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <!-- Header -->
    <div class="header">
        <div class="container">
            <h1>🥞 Martabak Lima</h1>
            <p>Martabak Terenak dengan Topping Pilihan Anda!</p>
        </div>
    </div>

    <!-- Navigation -->
    <nav class="nav">
        <div class="container">
            <ul class="nav-links">
                <li><a href="#menu" class="nav-link active">Menu</a></li>
                <li><a href="#custom" class="nav-link">Custom Order</a></li>
                <li><a href="#contact" class="nav-link">Kontak</a></li>
                <li><a href="admin/login.php" class="nav-link">Admin</a></li>
            </ul>
        </div>
    </nav>

    <!-- Menu Section -->
    <section id="menu" class="section">
        <div class="container">
            <h2 style="text-align: center; margin: 2rem 0; color: #ff6b35;">📋 Menu Paket</h2>
            
            <div class="menu-grid">
                <?php foreach($menu_packages as $menu): ?>
                <div class="menu-card">
                    <img src="https://via.placeholder.com/300x200/ff6b35/ffffff?text=<?php echo urlencode($menu['name']); ?>" 
                         alt="<?php echo htmlspecialchars($menu['name']); ?>">
                    <div class="menu-card-content">
                        <h3><?php echo htmlspecialchars($menu['name']); ?></h3>
                        <p><?php echo htmlspecialchars($menu['description']); ?></p>
                        <div class="price"><?php echo formatRupiah($menu['price']); ?></div>
                        <button class="btn" onclick="orderPackage(<?php echo $menu['id']; ?>, '<?php echo htmlspecialchars($menu['name']); ?>', <?php echo $menu['price']; ?>)">
                            Pesan Sekarang
                        </button>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Custom Order Section -->
    <section id="custom" class="section" style="background: white; padding: 3rem 0;">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 2rem; color: #ff6b35;">🎨 Custom Order</h2>
            
            <div class="admin-container" style="max-width: 600px;">
                <div class="admin-content">
                    <form id="customOrderForm">
                        <div class="form-group">
                            <label>Pilih Base Menu:</label>
                            <select class="form-control" id="baseMenu" required>
                                <option value="">-- Pilih Menu Dasar --</option>
                                <?php foreach($menu_packages as $menu): ?>
                                <option value="<?php echo $menu['id']; ?>" data-price="<?php echo $menu['price']; ?>">
                                    <?php echo htmlspecialchars($menu['name']); ?> - <?php echo formatRupiah($menu['price']); ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="form-group">
                            <label>Tambah Topping:</label>
                            <div class="topping-grid">
                                <?php foreach($toppings as $topping): ?>
                                <div class="topping-item" onclick="toggleTopping(this)">
                                    <input type="checkbox" name="toppings[]" value="<?php echo $topping['id']; ?>" 
                                           data-price="<?php echo $topping['price']; ?>" 
                                           data-name="<?php echo htmlspecialchars($topping['name']); ?>">
                                    <span><?php echo htmlspecialchars($topping['name']); ?></span>
                                    <div style="font-weight: bold; color: #f7931e;">
                                        + <?php echo formatRupiah($topping['price']); ?>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="customerName">Nama:</label>
                            <input type="text" class="form-control" id="customerName" required>
                        </div>

                        <div class="form-group">
                            <label for="customerPhone">No. HP:</label>
                            <input type="tel" class="form-control" id="customerPhone" required>
                        </div>

                        <div class="form-group">
                            <label for="notes">Catatan (opsional):</label>
                            <textarea class="form-control" id="notes" rows="3"></textarea>
                        </div>

                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                            <h4 style="color: #ff6b35; margin-bottom: 0.5rem;">Total Pesanan:</h4>
                            <div id="orderSummary">Pilih menu dan topping untuk melihat total</div>
                            <div style="font-size: 1.3rem; font-weight: bold; color: #f7931e; margin-top: 0.5rem;">
                                Total: <span id="totalPrice">Rp 0</span>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-success" style="width: 100%;">
                            🛒 Buat Pesanan
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section id="contact" class="section" style="background: #343a40; color: white; padding: 3rem 0;">
        <div class="container">
            <h2 style="text-align: center; margin-bottom: 2rem;">📞 Kontak Kami</h2>
            <div style="text-align: center; font-size: 1.1rem;">
                <p>📱 WhatsApp: <strong>0812-3456-7890</strong></p>
                <p>📍 Alamat: Jl. Martabak Lima No. 123, Kota Anda</p>
                <p>🕐 Buka: Setiap hari 15:00 - 23:00</p>
            </div>
        </div>
    </section>

    <script src="js/script.js"></script>
</body>
</html>
<?php
require_once 'config/database.php';
require_once 'includes/functions.php';

header('Content-Type: application/json');

if ($_POST['action'] === 'create_order') {
    try {
        $database = new Database();
        $db = $database->getConnection();
        
        // Sanitize input
        $menu_package_id = (int)$_POST['menu_package_id'];
        $customer_name = sanitizeInput($_POST['customer_name']);
        $customer_phone = sanitizeInput($_POST['customer_phone']);
        $notes = sanitizeInput($_POST['notes']);
        $total_price = (float)$_POST['total_price'];
        
        // Validate required fields
        if (empty($customer_name) || empty($customer_phone) || $menu_package_id <= 0) {
            throw new Exception('Data tidak lengkap');
        }
        
        // Start transaction
        $db->beginTransaction();
        
        // Insert order
        $query = "INSERT INTO orders (customer_name, customer_phone, menu_package_id, total_price, notes) 
                  VALUES (:customer_name, :customer_phone, :menu_package_id, :total_price, :notes)";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':customer_name', $customer_name);
        $stmt->bindParam(':customer_phone', $customer_phone);
        $stmt->bindParam(':menu_package_id', $menu_package_id);
        $stmt->bindParam(':total_price', $total_price);
        $stmt->bindParam(':notes', $notes);
        $stmt->execute();
        
        $order_id = $db->lastInsertId();
        
        // Insert toppings if any
        if (isset($_POST['toppings']) && is_array($_POST['toppings'])) {
            $topping_query = "INSERT INTO order_toppings (order_id, topping_id) VALUES (:order_id, :topping_id)";
            $topping_stmt = $db->prepare($topping_query);
            
            foreach ($_POST['toppings'] as $topping_id) {
                $topping_stmt->bindParam(':order_id', $order_id);
                $topping_stmt->bindParam(':topping_id', (int)$topping_id);
                $topping_stmt->execute();
            }
        }
        
        // Commit transaction
        $db->commit();
        
        echo json_encode([
            'success' => true,
            'order_id' => generateOrderId() . $order_id,
            'total' => $total_price,
            'message' => 'Pesanan berhasil dibuat'
        ]);
        
    } catch (Exception $e) {
        // Rollback transaction
        if ($db->inTransaction()) {
            $db->rollback();
        }
        
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid action'
    ]);
}
?>
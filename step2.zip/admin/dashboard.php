<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    redirectToLogin();
}

$database = new Database();
$db = $database->getConnection();

// Get statistics
$stats = [];

// Total orders
$query = "SELECT COUNT(*) as total FROM orders";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['total_orders'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Total revenue
$query = "SELECT SUM(total_price) as total FROM orders WHERE status != 'cancelled'";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['total_revenue'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'] ?? 0;

// Total menu packages
$query = "SELECT COUNT(*) as total FROM menu_packages WHERE is_active = 1";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['total_menu'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Total customers (unique)
$query = "SELECT COUNT(DISTINCT customer_phone) as total FROM orders";
$stmt = $db->prepare($query);
$stmt->execute();
$stats['total_customers'] = $stmt->fetch(PDO::FETCH_ASSOC)['total'];

// Recent orders
$query = "SELECT o.*, mp.name as menu_name 
          FROM orders o 
          LEFT JOIN menu_packages mp ON o.menu_package_id = mp.id 
          ORDER BY o.created_at DESC 
          LIMIT 10";
$stmt = $db->prepare($query);
$stmt->execute();
$recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin - Martabak Lima</title>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="admin-container">
        <!-- Header -->
        <div class="admin-header">
            <h1>🥞 Martabak Lima</h1>
            <p>Admin Dashboard - Selamat datang, <?php echo htmlspecialchars($_SESSION['admin_username']); ?>!</p>
        </div>
        
        <!-- Navigation -->
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php" class="active">📊 Dashboard</a></li>
                <li><a href="orders.php">📋 Pesanan</a></li>
                <li><a href="menu.php">🍽️ Menu</a></li>
                <li><a href="topping.php">🧀 Topping</a></li>
                <li><a href="logout.php">🔓 Logout</a></li>
                <li><a href="../index.php" target="_blank">🌐 Lihat Website</a></li>
            </ul>
        </nav>
        
        <!-- Content -->
        <div class="admin-content">
            <div class="content-header">
                <h2 class="content-title">Dashboard Overview</h2>
                <div style="color: #7f8c8d;">
                    📅 <?php echo date('d F Y, H:i'); ?>
                </div>
            </div>
            
            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card orders">
                    <div class="stat-number"><?php echo number_format($stats['total_orders']); ?></div>
                    <div class="stat-label">Total Pesanan</div>
                </div>
                
                <div class="stat-card revenue">
                    <div class="stat-number"><?php echo formatRupiah($stats['total_revenue']); ?></div>
                    <div class="stat-label">Total Pendapatan</div>
                </div>
                
                <div class="stat-card menu">
                    <div class="stat-number"><?php echo number_format($stats['total_menu']); ?></div>
                    <div class="stat-label">Menu Aktif</div>
                </div>
                
                <div class="stat-card customers">
                    <div class="stat-number"><?php echo number_format($stats['total_customers']); ?></div>
                    <div class="stat-label">Total Customer</div>
                </div>
            </div>
            
            <!-- Recent Orders -->
            <div class="admin-card">
                <div class="admin-card-header">
                    📋 Pesanan Terbaru
                </div>
                <div class="admin-card-body">
                    <?php if (count($recent_orders) > 0): ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Customer</th>
                                    <th>Menu</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($recent_orders as $order): ?>
                                <tr>
                                    <td><strong>#<?php echo $order['id']; ?></strong></td>
                                    <td>
                                        <div><?php echo htmlspecialchars($order['customer_name']); ?></div>
                                        <small style="color: #7f8c8d;"><?php echo htmlspecialchars($order['customer_phone']); ?></small>
                                    </td>
                                    <td><?php echo htmlspecialchars($order['menu_name']); ?></td>
                                    <td><strong><?php echo formatRupiah($order['total_price']); ?></strong></td>
                                    <td>
                                        <span class="badge badge-<?php echo $order['status']; ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d/m/Y H:i', strtotime($order['created_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <div style="text-align: center; margin-top: 1rem;">
                        <a href="orders.php" class="btn btn-primary">Lihat Semua Pesanan</a>
                    </div>
                    <?php else: ?>
                    <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <h3>Belum ada pesanan</h3>
                        <p>Pesanan baru akan muncul di sini</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="admin-card">
                <div class="admin-card-header">
                    ⚡ Quick Actions
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                        <a href="menu.php?action=add" class="btn btn-success">
                            ➕ Tambah Menu Baru
                        </a>
                        <a href="topping.php?action=add" class="btn btn-warning">
                            🧀 Tambah Topping Baru
                        </a>
                        <a href="orders.php?status=pending" class="btn btn-primary">
                            📋 Lihat Pesanan Pending
                        </a>
                        <a href="../index.php" target="_blank" class="btn btn-secondary">
                            🌐 Preview Website
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <style>
    .badge {
        padding: 0.3rem 0.8rem;
        border-radius: 15px;
        font-size: 0.8rem;
        font-weight: 500;
        text-transform: uppercase;
    }
    
    .badge-pending {
        background: #fff3cd;
        color: #856404;
    }
    
    .badge-processing {
        background: #d1ecf1;
        color: #0c5460;
    }
    
    .badge-completed {
        background: #d4edda;
        color: #155724;
    }
    
    .badge-cancelled {
        background: #f8d7da;
        color: #721c24;
    }
    </style>
</body>
</html>
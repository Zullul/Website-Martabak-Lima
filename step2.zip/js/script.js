// Global variables
let selectedToppings = [];
let baseMenuPrice = 0;
let totalPrice = 0;

// Navigation smooth scroll
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Remove active class from all links
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        // Add active class to clicked link
        this.classList.add('active');
        
        // Smooth scroll to section
        const targetId = this.getAttribute('href');
        if (targetId !== 'admin/login.php') {
            const targetSection = document.querySelector(targetId);
            if (targetSection) {
                targetSection.scrollIntoView({ behavior: 'smooth' });
            }
        }
    });
});

// Order package function
function orderPackage(menuId, menuName, price) {
    // Set base menu
    document.getElementById('baseMenu').value = menuId;
    document.getElementById('baseMenu').dispatchEvent(new Event('change'));
    
    // Scroll to custom order section
    document.querySelector('#custom').scrollIntoView({ behavior: 'smooth' });
    
    // Update nav
    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
    document.querySelector('a[href="#custom"]').classList.add('active');
}

// Toggle topping selection
function toggleTopping(element) {
    const checkbox = element.querySelector('input[type="checkbox"]');
    checkbox.checked = !checkbox.checked;
    
    if (checkbox.checked) {
        element.classList.add('selected');
    } else {
        element.classList.remove('selected');
    }
    
    updateOrderSummary();
}

// Update order summary
function updateOrderSummary() {
    const baseMenu = document.getElementById('baseMenu');
    const selectedToppings = document.querySelectorAll('input[name="toppings[]"]:checked');
    
    let summary = '';
    let total = 0;
    
    // Base menu
    if (baseMenu.value) {
        const selectedOption = baseMenu.options[baseMenu.selectedIndex];
        const menuName = selectedOption.text.split(' - ')[0];
        const menuPrice = parseFloat(selectedOption.dataset.price);
        
        summary += `<div><strong>Menu Dasar:</strong> ${menuName}</div>`;
        total += menuPrice;
        baseMenuPrice = menuPrice;
    }
    
    // Toppings
    if (selectedToppings.length > 0) {
        summary += '<div><strong>Topping:</strong></div>';
        selectedToppings.forEach(topping => {
            const name = topping.dataset.name;
            const price = parseFloat(topping.dataset.price);
            summary += `<div style="margin-left: 20px;">• ${name} (+${formatRupiah(price)})</div>`;
            total += price;
        });
    }
    
    if (summary === '') {
        summary = 'Pilih menu dan topping untuk melihat total';
    }
    
    document.getElementById('orderSummary').innerHTML = summary;
    document.getElementById('totalPrice').textContent = formatRupiah(total);
    totalPrice = total;
}

// Format rupiah in JavaScript
function formatRupiah(angka) {
    return 'Rp ' + angka.toLocaleString('id-ID');
}

// Base menu change handler
document.getElementById('baseMenu').addEventListener('change', updateOrderSummary);

// Custom order form submission
document.getElementById('customOrderForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const formData = new FormData();
    const baseMenu = document.getElementById('baseMenu').value;
    const customerName = document.getElementById('customerName').value;
    const customerPhone = document.getElementById('customerPhone').value;
    const notes = document.getElementById('notes').value;
    const selectedToppings = document.querySelectorAll('input[name="toppings[]"]:checked');
    
    if (!baseMenu) {
        alert('Silakan pilih menu dasar terlebih dahulu!');
        return;
    }
    
    if (!customerName || !customerPhone) {
        alert('Silakan lengkapi nama dan nomor HP!');
        return;
    }
    
    // Prepare data
    formData.append('action', 'create_order');
    formData.append('menu_package_id', baseMenu);
    formData.append('customer_name', customerName);
    formData.append('customer_phone', customerPhone);
    formData.append('notes', notes);
    formData.append('total_price', totalPrice);
    
    // Add selected toppings
    selectedToppings.forEach((topping, index) => {
        formData.append(`toppings[${index}]`, topping.value);
    });
    
    // Send order
    fetch('process_order.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Pesanan berhasil dibuat!\nNomor Order: ${data.order_id}\nTotal: ${formatRupiah(data.total)}\n\nSilakan hubungi WhatsApp kami untuk konfirmasi pembayaran.`);
            
            // Reset form
            document.getElementById('customOrderForm').reset();
            document.querySelectorAll('.topping-item').forEach(item => {
                item.classList.remove('selected');
            });
            updateOrderSummary();
        } else {
            alert('Terjadi kesalahan: ' + data.message);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Terjadi kesalahan saat memproses pesanan.');
    });
});

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    updateOrderSummary();
});
<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    redirectToLogin();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$message_type = '';

// Handle form submissions
if ($_POST) {
    try {
        if ($_POST['action'] == 'add') {
            $name = sanitizeInput($_POST['name']);
            $description = sanitizeInput($_POST['description']);
            $price = (float)$_POST['price'];
            
            if (empty($name) || $price <= 0) {
                throw new Exception('Nama menu dan harga harus diisi dengan benar!');
            }
            
            $query = "INSERT INTO menu_packages (name, description, price) VALUES (:name, :description, :price)";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);
            $stmt->execute();
            
            $message = 'Menu berhasil ditambahkan!';
            $message_type = 'success';
            
        } elseif ($_POST['action'] == 'edit') {
            $id = (int)$_POST['id'];
            $name = sanitizeInput($_POST['name']);
            $description = sanitizeInput($_POST['description']);
            $price = (float)$_POST['price'];
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            if (empty($name) || $price <= 0) {
                throw new Exception('Nama menu dan harga harus diisi dengan benar!');
            }
            
            $query = "UPDATE menu_packages SET name = :name, description = :description, price = :price, is_active = :is_active WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':description', $description);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':is_active', $is_active);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            $message = 'Menu berhasil diupdate!';
            $message_type = 'success';
            
        } elseif ($_POST['action'] == 'delete') {
            $id = (int)$_POST['id'];
            
            // Check if menu is used in orders
            $check_query = "SELECT COUNT(*) as count FROM orders WHERE menu_package_id = :id";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':id', $id);
            $check_stmt->execute();
            $order_count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($order_count > 0) {
                // Don't delete, just deactivate
                $query = "UPDATE menu_packages SET is_active = 0 WHERE id = :id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':id', $id);
                $stmt->execute();
                
                $message = 'Menu berhasil dinonaktifkan (tidak dapat dihapus karena sudah ada pesanan)!';
                $message_type = 'warning';
            } else {
                $query = "DELETE FROM menu_packages WHERE id = :id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':id', $id);
                $stmt->execute();
                
                $message = 'Menu berhasil dihapus!';
                $message_type = 'success';
            }
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $message_type = 'danger';
    }
}

// Get all menu packages
$query = "SELECT * FROM menu_packages ORDER BY name";
$stmt = $db->prepare($query);
$stmt->execute();
$menu_packages = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get edit data if needed
$edit_menu = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $query = "SELECT * FROM menu_packages WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $edit_id);
    $stmt->execute();
    $edit_menu = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Menu - Admin Martabak Lima</title>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="admin-container">
        <!-- Header -->
        <div class="admin-header">
            <h1>🍽️ Kelola Menu</h1>
            <p>Tambah, edit, dan kelola menu paket martabak</p>
        </div>
        
        <!-- Navigation -->
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="orders.php">📋 Pesanan</a></li>
                <li><a href="menu.php" class="active">🍽️ Menu</a></li>
                <li><a href="topping.php">🧀 Topping</a></li>
                <li><a href="logout.php">🔓 Logout</a></li>
            </ul>
        </nav>
        
        <!-- Content -->
        <div class="admin-content">
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Add/Edit Form -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <?php echo $edit_menu ? '✏️ Edit Menu' : '➕ Tambah Menu Baru'; ?>
                </div>
                <div class="admin-card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="<?php echo $edit_menu ? 'edit' : 'add'; ?>">
                        <?php if ($edit_menu): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_menu['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="name">Nama Menu:</label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?php echo $edit_menu ? htmlspecialchars($edit_menu['name']) : ''; ?>" 
                                       required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="price">Harga (Rp):</label>
                                <input type="number" class="form-control" id="price" name="price" 
                                       value="<?php echo $edit_menu ? $edit_menu['price'] : ''; ?>" 
                                       min="0" step="500" required>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label class="form-label" for="description">Deskripsi:</label>
                            <textarea class="form-control" id="description" name="description" rows="3"><?php echo $edit_menu ? htmlspecialchars($edit_menu['description']) : ''; ?></textarea>
                        </div>
                        
                        <?php if ($edit_menu): ?>
                        <div class="form-group">
                            <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                                <input type="checkbox" name="is_active" <?php echo $edit_menu['is_active'] ? 'checked' : ''; ?>>
                                Menu Aktif
                            </label>
                        </div>
                        <?php endif; ?>
                        
                        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $edit_menu ? '💾 Update Menu' : '➕ Tambah Menu'; ?>
                            </button>
                            
                            <?php if ($edit_menu): ?>
                            <a href="menu.php" class="btn btn-secondary">❌ Batal</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Menu List -->
            <div class="admin-card">
                <div class="admin-card-header">
                    📋 Daftar Menu (<?php echo count($menu_packages); ?> item)
                </div>
                <div class="admin-card-body">
                    <?php if (count($menu_packages) > 0): ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Menu</th>
                                    <th>Deskripsi</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($menu_packages as $menu): ?>
                                <tr style="<?php echo !$menu['is_active'] ? 'opacity: 0.6;' : ''; ?>">
                                    <td><strong>#<?php echo $menu['id']; ?></strong></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($menu['name']); ?></strong>
                                    </td>
                                    <td>
                                        <?php 
                                        $desc = htmlspecialchars($menu['description']);
                                        echo strlen($desc) > 50 ? substr($desc, 0, 50) . '...' : $desc;
                                        ?>
                                    </td>
                                    <td><strong><?php echo formatRupiah($menu['price']); ?></strong></td>
                                    <td>
                                        <span class="badge badge-<?php echo $menu['is_active'] ? 'completed' : 'cancelled'; ?>">
                                            <?php echo $menu['is_active'] ? 'Aktif' : 'Nonaktif'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($menu['created_at'])); ?></td>
                                    <td>
                                        <div style="display: flex; gap: 0.5rem;">
                                            <a href="menu.php?edit=<?php echo $menu['id']; ?>" class="btn btn-warning btn-sm">
                                                ✏️ Edit
                                            </a>
                                            <button onclick="deleteMenu(<?php echo $menu['id']; ?>, '<?php echo htmlspecialchars($menu['name']); ?>')" class="btn btn-danger btn-sm">
                                                🗑️ Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <h3>Belum ada menu</h3>
                        <p>Tambahkan menu pertama Anda menggunakan form di atas</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Form (Hidden) -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="deleteId">
    </form>
    
    <script>
        function deleteMenu(id, name) {
            if (confirm(`Apakah Anda yakin ingin menghapus menu "${name}"?\n\nJika menu ini pernah dipesan, maka akan dinonaktifkan saja.`)) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Auto format price input
        document.getElementById('price').addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^\d]/g, '');
            if (value) {
                // Round to nearest 500
                value = Math.round(value / 500) * 500;
                e.target.value = value;
            }
        });
    </script>
</body>
</html>
<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    redirectToLogin();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$message_type = '';

// Handle status update
if ($_POST && $_POST['action'] == 'update_status') {
    try {
        $order_id = (int)$_POST['order_id'];
        $status = sanitizeInput($_POST['status']);
        
        $valid_statuses = ['pending', 'processing', 'completed', 'cancelled'];
        if (!in_array($status, $valid_statuses)) {
            throw new Exception('Status tidak valid!');
        }
        
        $query = "UPDATE orders SET status = :status WHERE id = :id";
        $stmt = $db->prepare($query);
        $stmt->bindParam(':status', $status);
        $stmt->bindParam(':id', $order_id);
        $stmt->execute();
        
        $message = 'Status pesanan berhasil diupdate!';
        $message_type = 'success';
        
    } catch (Exception $e) {
        $message = $e->getMessage();
        $message_type = 'danger';
    }
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? sanitizeInput($_GET['status']) : '';
$search = isset($_GET['search']) ? sanitizeInput($_GET['search']) : '';

// Build query
$where_conditions = [];
$params = [];

if ($status_filter && $status_filter != 'all') {
    $where_conditions[] = "o.status = :status";
    $params[':status'] = $status_filter;
}

if ($search) {
    $where_conditions[] = "(o.customer_name LIKE :search OR o.customer_phone LIKE :search OR mp.name LIKE :search)";
    $params[':search'] = "%$search%";
}

$where_clause = count($where_conditions) > 0 ? 'WHERE ' . implode(' AND ', $where_conditions) : '';

// Get orders with menu and toppings
$query = "SELECT o.*, mp.name as menu_name 
          FROM orders o 
          LEFT JOIN menu_packages mp ON o.menu_package_id = mp.id 
          $where_clause
          ORDER BY o.created_at DESC";

$stmt = $db->prepare($query);
foreach ($params as $key => $value) {
    $stmt->bindValue($key, $value);
}
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get order toppings for each order
foreach ($orders as &$order) {
    $topping_query = "SELECT t.name, t.price 
                      FROM order_toppings ot 
                      JOIN toppings t ON ot.topping_id = t.id 
                      WHERE ot.order_id = :order_id";
    $topping_stmt = $db->prepare($topping_query);
    $topping_stmt->bindParam(':order_id', $order['id']);
    $topping_stmt->execute();
    $order['toppings'] = $topping_stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Get statistics
$stats_query = "SELECT 
                    COUNT(*) as total,
                    COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
                    COUNT(CASE WHEN status = 'processing' THEN 1 END) as processing,
                    COUNT(CASE WHEN status = 'completed' THEN 1 END) as completed,
                    COUNT(CASE WHEN status = 'cancelled' THEN 1 END) as cancelled
                FROM orders";
$stats_stmt = $db->prepare($stats_query);
$stats_stmt->execute();
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Pesanan - Admin Martabak Lima</title>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="admin-container">
        <!-- Header -->
        <div class="admin-header">
            <h1>📋 Kelola Pesanan</h1>
            <p>Monitor dan kelola semua pesanan martabak</p>
        </div>
        
        <!-- Navigation -->
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="orders.php" class="active">📋 Pesanan</a></li>
                <li><a href="menu.php">🍽️ Menu</a></li>
                <li><a href="topping.php">🧀 Topping</a></li>
                <li><a href="logout.php">🔓 Logout</a></li>
            </ul>
        </nav>
        
        <!-- Content -->
        <div class="admin-content">
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Order Statistics -->
            <div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); margin-bottom: 2rem;">
                <div class="stat-card orders">
                    <div class="stat-number"><?php echo $stats['total']; ?></div>
                    <div class="stat-label">Total</div>
                </div>
                <div class="stat-card" style="border-left-color: #f39c12;">
                    <div class="stat-number"><?php echo $stats['pending']; ?></div>
                    <div class="stat-label">Pending</div>
                </div>
                <div class="stat-card" style="border-left-color: #3498db;">
                    <div class="stat-number"><?php echo $stats['processing']; ?></div>
                    <div class="stat-label">Processing</div>
                </div>
                <div class="stat-card" style="border-left-color: #27ae60;">
                    <div class="stat-number"><?php echo $stats['completed']; ?></div>
                    <div class="stat-label">Completed</div>
                </div>
                <div class="stat-card" style="border-left-color: #e74c3c;">
                    <div class="stat-number"><?php echo $stats['cancelled']; ?></div>
                    <div class="stat-label">Cancelled</div>
                </div>
            </div>
            
            <!-- Filters -->
            <div class="admin-card">
                <div class="admin-card-header">
                    🔍 Filter & Pencarian
                </div>
                <div class="admin-card-body">
                    <form method="GET" action="">
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="status">Filter Status:</label>
                                <select class="form-control" id="status" name="status">
                                    <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>Semua Status</option>
                                    <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo $status_filter == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="search">Cari Pesanan:</label>
                                <input type="text" class="form-control" id="search" name="search" 
                                       value="<?php echo htmlspecialchars($search); ?>" 
                                       placeholder="Nama customer, HP, atau menu...">
                            </div>
                        </div>
                        
                        <div style="display: flex; gap: 1rem; margin-top: 1rem;">
                            <button type="submit" class="btn btn-primary">🔍 Filter</button>
                            <a href="orders.php" class="btn btn-secondary">🔄 Reset</a>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Orders List -->
            <div class="admin-card">
                <div class="admin-card-header">
                    📋 Daftar Pesanan (<?php echo count($orders); ?> pesanan)
                </div>
                <div class="admin-card-body">
                    <?php if (count($orders) > 0): ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Customer</th>
                                    <th>Pesanan</th>
                                    <th>Total</th>
                                    <th>Status</th>
                                    <th>Tanggal</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($orders as $order): ?>
                                <tr>
                                    <td><strong>#<?php echo $order['id']; ?></strong></td>
                                    <td>
                                        <div><strong><?php echo htmlspecialchars($order['customer_name']); ?></strong></div>
                                        <small style="color: #7f8c8d;">
                                            📱 <?php echo htmlspecialchars($order['customer_phone']); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div><strong><?php echo htmlspecialchars($order['menu_name']); ?></strong></div>
                                        <?php if (count($order['toppings']) > 0): ?>
                                        <small style="color: #7f8c8d;">
                                            + <?php echo implode(', ', array_column($order['toppings'], 'name')); ?>
                                        </small>
                                        <?php endif; ?>
                                        <?php if ($order['notes']): ?>
                                        <div style="font-size: 0.8rem; color: #666; margin-top: 0.3rem;">
                                            💬 <?php echo htmlspecialchars($order['notes']); ?>
                                        </div>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong><?php echo formatRupiah($order['total_price']); ?></strong></td>
                                    <td>
                                        <span class="badge badge-<?php echo $order['status']; ?>">
                                            <?php echo ucfirst($order['status']); ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div><?php echo date('d/m/Y', strtotime($order['created_at'])); ?></div>
                                        <small style="color: #7f8c8d;">
                                            <?php echo date('H:i', strtotime($order['created_at'])); ?>
                                        </small>
                                    </td>
                                    <td>
                                        <div style="display: flex; flex-direction: column; gap: 0.3rem;">
                                            <button onclick="viewOrder(<?php echo $order['id']; ?>)" class="btn btn-primary btn-sm">
                                                👁️ Detail
                                            </button>
                                            <button onclick="updateStatus(<?php echo $order['id']; ?>, '<?php echo $order['status']; ?>')" class="btn btn-warning btn-sm">
                                                🔄 Status
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <h3>Tidak ada pesanan</h3>
                        <p>
                            <?php if ($status_filter || $search): ?>
                            Tidak ada pesanan yang sesuai dengan filter Anda.
                            <?php else: ?>
                            Belum ada pesanan masuk.
                            <?php endif; ?>
                        </p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Order Detail Modal -->
    <div id="orderModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>📋 Detail Pesanan</h3>
            </div>
            <div class="modal-body" id="orderModalBody">
                <!-- Content will be loaded here -->
            </div>
        </div>
    </div>
    
    <!-- Status Update Modal -->
    <div id="statusModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3>🔄 Update Status Pesanan</h3>
            </div>
            <div class="modal-body">
                <form method="POST" action="">
                    <input type="hidden" name="action" value="update_status">
                    <input type="hidden" name="order_id" id="statusOrderId">
                    
                    <div class="form-group">
                        <label class="form-label" for="statusSelect">Status Baru:</label>
                        <select class="form-control" id="statusSelect" name="status" required>
                            <option value="pending">⏰ Pending</option>
                            <option value="processing">🔄 Processing</option>
                            <option value="completed">✅ Completed</option>
                            <option value="cancelled">❌ Cancelled</option>
                        </select>
                    </div>
                    
                    <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                        <button type="submit" class="btn btn-primary">💾 Update Status</button>
                        <button type="button" onclick="closeModal('statusModal')" class="btn btn-secondary">❌ Batal</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        function viewOrder(orderId) {
            // In a real application, you would fetch order details via AJAX
            document.getElementById('orderModalBody').innerHTML = '<p>Loading order details...</p>';
            document.getElementById('orderModal').style.display = 'block';
            
            // Simulated order detail loading
            setTimeout(() => {
                document.getElementById('orderModalBody').innerHTML = `
                    <div>
                        <h4>Order #${orderId}</h4>
                        <p>Detail pesanan akan ditampilkan di sini...</p>
                        <button onclick="closeModal('orderModal')" class="btn btn-secondary">Tutup</button>
                    </div>
                `;
            }, 500);
        }
        
        function updateStatus(orderId, currentStatus) {
            document.getElementById('statusOrderId').value = orderId;
            document.getElementById('statusSelect').value = currentStatus;
            document.getElementById('statusModal').style.display = 'block';
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).style.display = 'none';
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            const orderModal = document.getElementById('orderModal');
            const statusModal = document.getElementById('statusModal');
            
            if (event.target == orderModal) {
                orderModal.style.display = 'none';
            }
            if (event.target == statusModal) {
                statusModal.style.display = 'none';
            }
        }
        
        // Auto refresh every 30 seconds for new orders
        setInterval(() => {
            const urlParams = new URLSearchParams(window.location.search);
            if (!urlParams.has('status') || urlParams.get('status') === 'pending') {
                location.reload();
            }
        }, 30000);
    </script>
</body>
</html>
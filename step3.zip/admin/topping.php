<?php
require_once '../config/database.php';
require_once '../includes/functions.php';

// Check if admin is logged in
if (!isAdminLoggedIn()) {
    redirectToLogin();
}

$database = new Database();
$db = $database->getConnection();

$message = '';
$message_type = '';

// Handle form submissions
if ($_POST) {
    try {
        if ($_POST['action'] == 'add') {
            $name = sanitizeInput($_POST['name']);
            $price = (float)$_POST['price'];
            
            if (empty($name) || $price < 0) {
                throw new Exception('Nama topping harus diisi dan harga tidak boleh negatif!');
            }
            
            $query = "INSERT INTO toppings (name, price) VALUES (:name, :price)";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':price', $price);
            $stmt->execute();
            
            $message = 'Topping berhasil ditambahkan!';
            $message_type = 'success';
            
        } elseif ($_POST['action'] == 'edit') {
            $id = (int)$_POST['id'];
            $name = sanitizeInput($_POST['name']);
            $price = (float)$_POST['price'];
            $is_active = isset($_POST['is_active']) ? 1 : 0;
            
            if (empty($name) || $price < 0) {
                throw new Exception('Nama topping harus diisi dan harga tidak boleh negatif!');
            }
            
            $query = "UPDATE toppings SET name = :name, price = :price, is_active = :is_active WHERE id = :id";
            $stmt = $db->prepare($query);
            $stmt->bindParam(':name', $name);
            $stmt->bindParam(':price', $price);
            $stmt->bindParam(':is_active', $is_active);
            $stmt->bindParam(':id', $id);
            $stmt->execute();
            
            $message = 'Topping berhasil diupdate!';
            $message_type = 'success';
            
        } elseif ($_POST['action'] == 'delete') {
            $id = (int)$_POST['id'];
            
            // Check if topping is used in orders
            $check_query = "SELECT COUNT(*) as count FROM order_toppings WHERE topping_id = :id";
            $check_stmt = $db->prepare($check_query);
            $check_stmt->bindParam(':id', $id);
            $check_stmt->execute();
            $order_count = $check_stmt->fetch(PDO::FETCH_ASSOC)['count'];
            
            if ($order_count > 0) {
                // Don't delete, just deactivate
                $query = "UPDATE toppings SET is_active = 0 WHERE id = :id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':id', $id);
                $stmt->execute();
                
                $message = 'Topping berhasil dinonaktifkan (tidak dapat dihapus karena sudah ada pesanan)!';
                $message_type = 'warning';
            } else {
                $query = "DELETE FROM toppings WHERE id = :id";
                $stmt = $db->prepare($query);
                $stmt->bindParam(':id', $id);
                $stmt->execute();
                
                $message = 'Topping berhasil dihapus!';
                $message_type = 'success';
            }
        }
    } catch (Exception $e) {
        $message = $e->getMessage();
        $message_type = 'danger';
    }
}

// Get all toppings
$query = "SELECT * FROM toppings ORDER BY name";
$stmt = $db->prepare($query);
$stmt->execute();
$toppings = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Get edit data if needed
$edit_topping = null;
if (isset($_GET['edit'])) {
    $edit_id = (int)$_GET['edit'];
    $query = "SELECT * FROM toppings WHERE id = :id";
    $stmt = $db->prepare($query);
    $stmt->bindParam(':id', $edit_id);
    $stmt->execute();
    $edit_topping = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Topping - Admin Martabak Lima</title>
    <link rel="stylesheet" href="css/admin-style.css">
</head>
<body>
    <div class="admin-container">
        <!-- Header -->
        <div class="admin-header">
            <h1>🧀 Kelola Topping</h1>
            <p>Tambah, edit, dan kelola topping martabak</p>
        </div>
        
        <!-- Navigation -->
        <nav class="admin-nav">
            <ul>
                <li><a href="dashboard.php">📊 Dashboard</a></li>
                <li><a href="orders.php">📋 Pesanan</a></li>
                <li><a href="menu.php">🍽️ Menu</a></li>
                <li><a href="topping.php" class="active">🧀 Topping</a></li>
                <li><a href="logout.php">🔓 Logout</a></li>
            </ul>
        </nav>
        
        <!-- Content -->
        <div class="admin-content">
            <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?>">
                <?php echo $message; ?>
            </div>
            <?php endif; ?>
            
            <!-- Add/Edit Form -->
            <div class="admin-card">
                <div class="admin-card-header">
                    <?php echo $edit_topping ? '✏️ Edit Topping' : '➕ Tambah Topping Baru'; ?>
                </div>
                <div class="admin-card-body">
                    <form method="POST" action="">
                        <input type="hidden" name="action" value="<?php echo $edit_topping ? 'edit' : 'add'; ?>">
                        <?php if ($edit_topping): ?>
                        <input type="hidden" name="id" value="<?php echo $edit_topping['id']; ?>">
                        <?php endif; ?>
                        
                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label" for="name">Nama Topping:</label>
                                <input type="text" class="form-control" id="name" name="name" 
                                       value="<?php echo $edit_topping ? htmlspecialchars($edit_topping['name']) : ''; ?>" 
                                       placeholder="Contoh: Keju, Coklat, Kacang..." required>
                            </div>
                            
                            <div class="form-group">
                                <label class="form-label" for="price">Harga Tambahan (Rp):</label>
                                <input type="number" class="form-control" id="price" name="price" 
                                       value="<?php echo $edit_topping ? $edit_topping['price'] : ''; ?>" 
                                       min="0" step="500" required>
                                <small style="color: #7f8c8d; margin-top: 0.5rem; display: block;">
                                    Masukkan 0 jika topping gratis
                                </small>
                            </div>
                        </div>
                        
                        <?php if ($edit_topping): ?>
                        <div class="form-group">
                            <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                                <input type="checkbox" name="is_active" <?php echo $edit_topping['is_active'] ? 'checked' : ''; ?>>
                                Topping Aktif
                            </label>
                        </div>
                        <?php endif; ?>
                        
                        <div style="display: flex; gap: 1rem; margin-top: 2rem;">
                            <button type="submit" class="btn btn-primary">
                                <?php echo $edit_topping ? '💾 Update Topping' : '➕ Tambah Topping'; ?>
                            </button>
                            
                            <?php if ($edit_topping): ?>
                            <a href="topping.php" class="btn btn-secondary">❌ Batal</a>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            
            <!-- Topping List -->
            <div class="admin-card">
                <div class="admin-card-header">
                    📋 Daftar Topping (<?php echo count($toppings); ?> item)
                </div>
                <div class="admin-card-body">
                    <?php if (count($toppings) > 0): ?>
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Nama Topping</th>
                                    <th>Harga</th>
                                    <th>Status</th>
                                    <th>Tanggal Dibuat</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($toppings as $topping): ?>
                                <tr style="<?php echo !$topping['is_active'] ? 'opacity: 0.6;' : ''; ?>">
                                    <td><strong>#<?php echo $topping['id']; ?></strong></td>
                                    <td>
                                        <strong><?php echo htmlspecialchars($topping['name']); ?></strong>
                                    </td>
                                    <td>
                                        <strong>
                                            <?php echo $topping['price'] > 0 ? '+' . formatRupiah($topping['price']) : 'GRATIS'; ?>
                                        </strong>
                                    </td>
                                    <td>
                                        <span class="badge badge-<?php echo $topping['is_active'] ? 'completed' : 'cancelled'; ?>">
                                            <?php echo $topping['is_active'] ? 'Aktif' : 'Nonaktif'; ?>
                                        </span>
                                    </td>
                                    <td><?php echo date('d/m/Y', strtotime($topping['created_at'])); ?></td>
                                    <td>
                                        <div style="display: flex; gap: 0.5rem;">
                                            <a href="topping.php?edit=<?php echo $topping['id']; ?>" class="btn btn-warning btn-sm">
                                                ✏️ Edit
                                            </a>
                                            <button onclick="deleteTopping(<?php echo $topping['id']; ?>, '<?php echo htmlspecialchars($topping['name']); ?>')" class="btn btn-danger btn-sm">
                                                🗑️ Hapus
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div style="text-align: center; padding: 2rem; color: #7f8c8d;">
                        <h3>Belum ada topping</h3>
                        <p>Tambahkan topping pertama Anda menggunakan form di atas</p>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <!-- Popular Topping Ideas -->
            <div class="admin-card">
                <div class="admin-card-header">
                    💡 Ide Topping Populer
                </div>
                <div class="admin-card-body">
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem;">
                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                            <h4 style="color: #e74c3c; margin-bottom: 0.5rem;">🧀 Topping Manis</h4>
                            <ul style="margin: 0; padding-left: 1.2rem; color: #666;">
                                <li>Keju</li>
                                <li>Coklat</li>
                                <li>Kacang</li>
                                <li>Susu</li>
                                <li>Selai</li>
                            </ul>
                        </div>
                        
                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                            <h4 style="color: #27ae60; margin-bottom: 0.5rem;">🥓 Topping Gurih</h4>
                            <ul style="margin: 0; padding-left: 1.2rem; color: #666;">
                                <li>Sosis</li>
                                <li>Kornet</li>
                                <li>Daging</li>
                                <li>Ayam</li>
                                <li>Tuna</li>
                            </ul>
                        </div>
                        
                        <div style="background: #f8f9fa; padding: 1rem; border-radius: 8px;">
                            <h4 style="color: #f39c12; margin-bottom: 0.5rem;">🥬 Topping Sayur</h4>
                            <ul style="margin: 0; padding-left: 1.2rem; color: #666;">
                                <li>Jagung</li>
                                <li>Wortel</li>
                                <li>Kubis</li>
                                <li>Bawang</li>
                                <li>Paprika</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Delete Form (Hidden) -->
    <form id="deleteForm" method="POST" style="display: none;">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" id="deleteId">
    </form>
    
    <script>
        function deleteTopping(id, name) {
            if (confirm(`Apakah Anda yakin ingin menghapus topping "${name}"?\n\nJika topping ini pernah dipesan, maka akan dinonaktifkan saja.`)) {
                document.getElementById('deleteId').value = id;
                document.getElementById('deleteForm').submit();
            }
        }
        
        // Auto format price input
        document.getElementById('price').addEventListener('input', function(e) {
            let value = e.target.value.replace(/[^\d]/g, '');
            if (value) {
                // Round to nearest 500
                value = Math.round(value / 500) * 500;
                e.target.value = value;
            }
        });
        
        // Quick add popular toppings
        document.querySelectorAll('ul li').forEach(item => {
            item.style.cursor = 'pointer';
            item.title = 'Klik untuk menambahkan ke form';
            item.addEventListener('click', function() {
                const nameField = document.getElementById('name');
                if (nameField.value === '') {
                    nameField.value = this.textContent;
                    nameField.focus();
                }
            });
        });
    </script>
</body>
</html>